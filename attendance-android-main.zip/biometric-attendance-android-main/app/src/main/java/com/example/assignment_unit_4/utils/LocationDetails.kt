package com.example.assignment_unit_4.utils

data class LocationDetails(val latitude: Double, val longitude: Double)
